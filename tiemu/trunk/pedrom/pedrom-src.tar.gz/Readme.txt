This is a version of PedroM 0.80 modified for compatibility with ld-tigcc and with the
TI-89 Titanium. See pedrom-080-ld-tigcc-and-titanium-fixes.diff for my changes.
        Kevin Kofler

I also removed the non-Free components (the ExtGraph-based BitmapGet, BitmapPut and
DrawIcon which have to be rewritten and clipping support has been added, the TIB
Receiver, the builtin ttunpack, the builtin stdlib archive pack and the WTI support
have been removed). See pedrom-080-del-nonfree.diff for the changes I had to make to
PedroM for this. The actual deletions aren't in the diff for obvious reasons.
        Kevin Kofler